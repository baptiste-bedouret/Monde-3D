
#pragma once


namespace glbinding
{


using ContextHandle = long long int; ///< Type for storing OpenGL context handles


} // namespace glbinding
