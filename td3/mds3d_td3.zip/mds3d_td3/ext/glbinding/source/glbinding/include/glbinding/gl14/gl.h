#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl14/types.h>
#include <glbinding/gl14/boolean.h>
#include <glbinding/gl14/values.h>
#include <glbinding/gl14/bitfield.h>
#include <glbinding/gl14/enum.h>
#include <glbinding/gl14/functions.h>
