#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl13/types.h>
#include <glbinding/gl13/boolean.h>
#include <glbinding/gl13/values.h>
#include <glbinding/gl13/bitfield.h>
#include <glbinding/gl13/enum.h>
#include <glbinding/gl13/functions.h>
