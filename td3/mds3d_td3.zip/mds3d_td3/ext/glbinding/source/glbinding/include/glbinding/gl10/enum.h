#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/enum.h>


namespace gl10
{


// import enums to namespace



} // namespace gl10
