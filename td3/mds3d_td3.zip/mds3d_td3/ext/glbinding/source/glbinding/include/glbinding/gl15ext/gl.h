#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl15ext/types.h>
#include <glbinding/gl15ext/boolean.h>
#include <glbinding/gl15ext/values.h>
#include <glbinding/gl15ext/bitfield.h>
#include <glbinding/gl15ext/enum.h>
#include <glbinding/gl15ext/functions.h>
